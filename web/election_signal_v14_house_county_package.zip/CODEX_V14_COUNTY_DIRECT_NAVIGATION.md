# Election Signal V14 — House county → congressional district overlay

## Product behavior (UI approved for implementation evaluation)

**User journey:** House (national) → select state → select any county on county map → immediately transition to a page focused on that county, with district boundaries overlaid. No intermediate county profile or extra button. Selection from county search/table must behave the same way. State/office and other global context remain preserved.

The standalone prototype displays **a real reference county outline** with **three clearly labeled illustrative sections**. These sections are *not* 2026 congressional districts. Actual production data must replace this schematic; do not infer an official district ID or subdivide results by polygon area.

## Correct production geography

1. Import a verified, election-applicable vintage of US House congressional-district polygons (Census 120th Congressional Districts or updated authoritative state sources as appropriate) and canonical county polygons. Validate which enacted map applies to the November 2026 elections, especially redistricted states.
2. Store polygons in PostGIS with explicit CRS/SRID, geoid/FIPS, source provenance, vintage, simplification levels and effective dates.
3. Precompute district/county intersections using `ST_Intersection` after `ST_Intersects`, check geometries with `ST_IsValid`/`ST_MakeValid` if necessary, and clip at the proper county boundary.
4. For every county, return only the real districts that intersect it. Some counties have one district; others have several. Do not always force three divisions.
5. Ensure geographic geometry does **not** imply reported election results. District votes should come from the corresponding race and verified reporting units; when the source has no district-level result, say unavailable.
6. The client should be able to click/tap any polygon, highlight the segment, and inspect district ID, candidate totals, estimated-vote counted *if sourced*, last source update and 2022/2024 comparison *if geographically valid*.

### Proposed API

`GET /api/v1/elections/2026/states/{state}/counties/{countyFips}/house-districts`

Response needs: `county` identity/geometry, `geographyVersion`, `source`, `sourceAsOf`, `status`, `districtIntersections[]` containing `districtId`, `geometry`, `isWholeCounty`, `raceId`, `reportingMeasure`, `sourceTimestamp`. In partial or unverified coverage send unavailable statuses, not fictional shapes.

### Route and interactions

- Semantic route shape: `/elections/2026/states/TX/house/counties/48201/districts`.
- House state county-map click calls direct route; non-House county clicks retain the appropriate statewide county detail behavior.
- Breadcrumbs: National → State → House → County / Districts.
- County switcher and Return to House county map.
- Hover/focus/click segment, keyboard controls, mobile tap, reduced motion.
- Back and forward retain selected state, county, office and mode.
- React/Next.js should reuse V12/V13 map styling and not replicate the schematic zones in production datasets.

### Required tests

- Clicking Harris County from Texas House map opens Harris-focused map in one interaction.
- Clicking a county in search and results table opens the same map.
- Changing county from dropdown updates county outline and selections.
- Selecting region updates inspector and aria-pressed state.
- Governor/Senate county flows are unchanged.
- All 254 Texas counties are selectable from county search; do not infer or impose district count.
- Missing district geometry shows an honest unavailable state.
- County intersection of 1, 2, 3+ districts dynamically alters the number of map segments.
- No crosswalk based on proportional polygon area; split county reporting must be source-grounded.
- Desktop/mobile no horizontal overflow, no JavaScript exceptions.

## Reference

`election_signal_v14_house_county_direct.html` demonstrates the *navigation and component behavior only*; production geometry must be verified and sourced.
